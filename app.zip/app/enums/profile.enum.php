<?php

namespace App\Enums;

// Énumération des profils utilisateurs dans le format procédural
const ADMIN = 'Admin';
const VIGILE = 'Vigile';
const APPRENANT = 'Apprenant';
const ATTACHE = 'Attache';  // Ajoutez cette ligne