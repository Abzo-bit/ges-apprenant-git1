<?php

namespace App\Translate\fr;

$success_messages = [
    'auth' => [
        'login_success' => 'Connexion réussie',
        'logout_success' => 'Déconnexion réussie'
    ]
];

return $success_messages;