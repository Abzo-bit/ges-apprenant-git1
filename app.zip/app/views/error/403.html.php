<div style="text-align: center; padding: 40px 20px;">
    <h1 style="font-size: 72px; color: #e74c3c; margin-bottom: 20px;">403</h1>
    <h2 style="margin-bottom: 20px; color: #333;">Accès interdit</h2>
    <p style="margin-bottom: 30px; color: #666;">Vous n'avez pas les droits nécessaires pour accéder à cette page.</p>
    <a href="?page=login" style="display: inline-block; background-color: #0E8F7E; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Retour à la page de connexion</a>
</div>